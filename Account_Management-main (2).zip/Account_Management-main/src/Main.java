
public class Main {
    public static void main(String[] args) {
        PersonalAccount adik = new PersonalAccount(220104008, "Aruuke");
        PersonalAccount azar = new PersonalAccount(220104002, "Sezim");
        adik.deposit(400);
        try {
            adik.withdraw(-500);
        }
        catch(InsufficientBalanceException ex){
            System.out.println(ex.getMessage());
        }
        
        adik.printTransactionHistory();
    }
}
